GnuCash for Android is a community effort which is made possible by the contributions of
several different people.
Appreciation goes to Muslim Chochlov and the to whole GnuCash community for guiding the
project through the early phases (as Google Summer of Code project 2012) and providing valuable feedback.

### Core Developers:
* Ngewi Fet <ngewif@gmail.com> - Project maintainer
* Yongxin Wang <fefe.wyx@gmail.com>
* Oleksandr Tyshkovets <olexandr.tyshkovets@gmail.com>
* Àlex Magaz Graça <alexandre.magaz@gmail.com>

### Other Contributors
The following people (in alphabetical order) contributed (commits on GitHub) to GnuCash Android:
* aerkefiende
* Alceu Rodrigues Neto
* Aleksey Ivanovski
* Àlex Magaz Graça
* Alexander Galanin
* Alexandr Makaric
* Caesar Wirth
* Carlo Zancanaro
* choni wani@dri-h.net
* Christian Stimming
* Cristian Marchi
* David Landry
* Eric Daly
* Falk Brockmann
* Felipe Morato
* Geert Janssens
* Gleb Semyannikov
* Jörg Möller
* Israel Buitron
* Jesse Shieh
* Jorge Martínez López
* Juan Villa
* Kjell Thomas Pedersen
* Lian Kai
* lxb leixb@agilean.cn
* Alex Lei
* Mark Haanen
* Matthew Hague
* Menelaos Maglis
* moshe.w@invest.com
* Ngewi Fet
* Nicolas Barranger
* Oleg Kosmakov
* Oleksandr Tyshkovets
* PBNeves bastosdasneves@gmail.com
* Pedro Abel
* Salama AB
* Sandro Santilli
* Sigurd Gartmann
* smisger sameer.misger@prospectasoftware.com
* Spanti Nicola
* Stephan Windmüller
* Terry Chung
* thesebas thesebas@thesebas.net
* Timur Badretdinov
* Timur Khuzin
* Vladimir Rutsky
* Weslly Oliveira
* windwarrior lennartbuit@gmail.com
* yapiti wicowyn@gmail.com
* Yongxin Wang


### Translators
Please visit https://crowdin.com/project/gnucash-android for a more complete list of translation contributions
