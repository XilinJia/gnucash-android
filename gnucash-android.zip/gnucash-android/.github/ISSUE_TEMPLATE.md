#### Steps to reproduce the behaviour
1. <!-- List the detail steps to reproduce the problem here -->

#### Expected behaviour


#### Actual behaviour


#### Software specifications
* GnuCash Android version:
* System Android version:
* Device type:
